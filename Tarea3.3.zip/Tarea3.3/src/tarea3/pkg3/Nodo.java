/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tarea3.pkg3;

/**
 * 
 * @author Erick Hernández
 */
public class Nodo {

    // Variables en las cuales se van a guardar los valores.
    String valor;
    String valor2;
    // Variable para enlazar los nodos.
    Nodo siguiente;
   // Constructor que inicializamos el valor de las variables.
      public Nodo(String valor, String valor2){
        this.valor = valor;
        this.valor2 = valor2;
        this.siguiente = null;
    }
    // Métodos getters y setters para los variables.
    public String getValor() {
        return valor;
    }
    public void setValor(String valor) {
        this.valor = valor;
    }
    public Nodo getSiguiente() {
        return siguiente;
    }
    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }  

    public String getValor2() {
        return valor2;
    }

    public void setValor2(String valor2) {
        this.valor2 = valor2;
    }
}
