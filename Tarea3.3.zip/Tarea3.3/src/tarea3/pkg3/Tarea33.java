package tarea3.pkg3;
/**
 *
 * @author Erick Hernández
 */
public class Tarea33 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Se declara un objeto de la clase Contacto, para ayudarnos a iniciar con el programa
          Contacto aux= new Contacto();
          //Se manda llamar el menu de la clase Contacto.
          //En donde se realizaran todas las operaciones
          //del programa         
          aux.menu();
    }
    
}
