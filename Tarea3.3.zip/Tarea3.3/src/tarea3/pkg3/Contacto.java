/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tarea3.pkg3;
import java.util.Scanner;
import java.util.InputMismatchException;

/**
 * 
 * @author Erick Hernández
 */
public class Contacto {
    // Inicio de la lista o conocida tambien
    private Nodo inicio;
    private String nombre;
    private String numero;
    // Variable para registrar el tamaño de la lista.
    private int tamanio;
   // Constructor que inicializamos el valor de la variable.
    public void Contacto(){
        inicio = null;
        tamanio = 0;
    }
    public int getTamanio(){
        return tamanio;
    }
       public void agregarAlFinal(String valor, String valor2){
        // Define un nuevo nodo y agrega el valor.
        Nodo nuevo = new Nodo(valor,valor2);
        // Consulta si la lista esta vacia.
        if (esVacia()) {
            // Inicializa la lista agregando como inicio al nuevo nodo.
            inicio = nuevo;
        // Caso contrario recorre la lista hasta llegar al ultimo nodo
        //y agrega el nuevo.
        } else{
            // Crea ua copia de la lista.
            Nodo aux = inicio;
            // Recorre la lista hasta llegar al ultimo nodo.
            while(aux.getSiguiente() != null){
                aux = aux.getSiguiente();
            }
            // Agrega el nuevo nodo al final de la lista.
            // usando el mé todo llamado setSiguiente de la clase Nodo, este crea el nuevo enlace entre el ultimo nodo y el nuevo,
            //ya que hace referencia a otro nodo.
            aux.setSiguiente(nuevo);
        }
         // Incrementa el contador de tamaño de la lista
        tamanio++;
    }
      //verifica si la lista esta vacia 
     public boolean esVacia(){
         //Si el valor de la variable inicio es null, se regresa un true, indicando que la lista esta vacía
        if (inicio == null) {
            return true;
         //Si el valor de la variable inicio no es null, se regresa un false, indicando que la lista no esta vacía
        }else{
            return false;
        }     
    }
         //Metodo que manda a pantalla los  valores de todos los nodos.
     public void listar(){
        // Verifica si la lista esta vacia.
        if (!esVacia()) {
            // Crea una copia de la lista.
            Nodo aux = inicio;
            // Posicion de los elementos de la lista.
            //Se inicia en 1 porque asi inician las listas de alumnos de las escuelas
            int i = 1;
            // Recorre la lista hasta el final.
            System.out.println("*****************************************");
            System.out.println("           LISTA CONTACTOS: ");
            System.out.println("*****************************************");
            while(aux != null){
                // Imprime en pantalla el valor del nodo.
                System.out.println(i+". Nombre: "+aux.getValor()+", Número: "+aux.getValor2());
                // Avanza al siguiente nodo.
                aux = aux.getSiguiente();
                // Incrementa el contador de la posión.
                i++;
            }
            
        }
    }
     
     //Metodo que busca el valor mediante el nombre del nodo
      public boolean buscarPorNombre(String referencia){
        // Crea una copia de la lista.
        Nodo aux = inicio;
        // Bandera para indicar si el valor existe.
        boolean encontrado = false;
        // Recorre la lista hasta encontrar el elemento o hasta 
        // llegar al final de la lista.
        while(aux != null && encontrado != true){
            // Consulta si el valor del nodo es igual al de referencia.
            //Como las variables son de tipo String se utiliza el equals para compararlas
            if (referencia.equals(aux.getValor())){
                // Canbia el valor de la bandera.
                encontrado = true;
            }
            else{
                // Avansa al siguiente. nodo.
                aux = aux.getSiguiente();
            }
        }
        // Retorna el resultado de la variable encontrado.
        return encontrado;
    }
      //Método que busca el valor2 mediante el telefono del nodo
      public boolean buscarPorTelefono(String referencia2){        
        // Crea una copia de la lista.
        Nodo aux = inicio;
        // Bandera para indicar si el valor existe.
        boolean encontrado = false;
        // Recorre la lista hasta encontrar el elemento o hasta 
        // llegar al final de la lista.
        while(aux != null && encontrado != true){
            // Consulta si el valor del nodo es igual al de referencia.
            //Como las variables son de tipo String se utiliza el equals para compararlas
            if (referencia2.equals(aux.getValor2())){
                // Canbia el valor de la bandera.
                encontrado = true;
            }
            else{
                // Avansa al siguiente. nodo.
                aux = aux.getSiguiente();
            }
        }
        // Retorna el resultado de la variable encontrado.
        return encontrado;
    }
      
      //Método que elimina el nodo mediante el nombre (valor) del nodo.
      public void eliminarPorNombre(String referencia){
        // Consulta si el valor de referencia existe en la lista.
        if (buscarPorNombre(referencia)) {
            // Consulta si el nodo a eliminar es el pirmero
            if (inicio.getValor().equals( referencia)) {
                // El primer nodo apunta al siguiente.
                inicio = inicio.getSiguiente();
            } else{
                // Crea ua copia de la lista.
                Nodo aux = inicio;
                // Recorre la lista hasta llegar al nodo anterior 
                // al de referencia.
                //Como las variables son de tipo String se utiliza el equals para compararlas
                while(!(aux.getSiguiente().getValor().equals(referencia))){
                    aux = aux.getSiguiente();
                }
                // Guarda el nodo siguiente del nodo a eliminar.
                Nodo siguiente = aux.getSiguiente().getSiguiente();
                // Enlaza el nodo anterior al de eliminar con el 
                // sguiente despues de el.
                aux.setSiguiente(siguiente);  
            }
            // Disminuye el contador de tamaño de la lista.
            tamanio--;
        }
      
      }
        //Método que elimina el nodo mediante el telefono (valor2) del nodo.
        public void eliminarPorTelefono(String referencia2){
        // Consulta si el valor de referencia existe en la lista.
        if (buscarPorTelefono(referencia2)) {
            // Consulta si el nodo a eliminar es el pirmero
            if (inicio.getValor2().equals(referencia2)) {
                // El primer nodo apunta al siguiente.
                inicio = inicio.getSiguiente();
            } else{
                // Crea ua copia de la lista.
                Nodo aux = inicio;
                // Recorre la lista hasta llegar al nodo anterior 
                // al de referencia.
                //Como las variables son de tipo String se utiliza el equals para compararlas
                while(!(aux.getSiguiente().getValor2().equals(referencia2))){
                    aux = aux.getSiguiente();
                }
                // Guarda el nodo siguiente del nodo a eliminar.
                Nodo siguiente = aux.getSiguiente().getSiguiente();
                // Enlaza el nodo anterior al de eliminar con el 
                // sguiente despues de el.
                aux.setSiguiente(siguiente);  
            }
            // Disminuye el contador de tamaño de la lista.
            tamanio--;
        }
    }
        //Método que actualiza el valor del nodo mediante el valor (nombre) del nodo.
        public void editarPorNombre(String referencia, String nuevoV){
        // Consulta si el valor existe en la lista.
        if (buscarPorNombre(referencia)) {
            // Crea ua copia de la lista.
            Nodo aux = inicio;
            // Recorre la lista hasta llegar al nodo de referencia.
            //Como las variables son de tipo String se utiliza el equals para compararlas
            while(!(aux.getValor().equals(referencia))){
                aux = aux.getSiguiente();
            }
            // Actualizamos el valor del nodo que corresponde al nombre
            aux.setValor(nuevoV);
        }
    }
        //Método que actualiza el valor del nodo mediante el valor2 (telefono) del nodo.
        public void editarPorTelefono(String referencia2, String nuevoV2){
        // Consulta si el valor existe en la lista.
        if (buscarPorTelefono(referencia2)) {
            // Crea ua copia de la lista.
            Nodo aux = inicio;
            // Recorre la lista hasta llegar al nodo de referencia.
            //Como las variables son de tipo String se utiliza el equals para compararlas
            while(!(aux.getValor2().equals(referencia2))){
                aux = aux.getSiguiente();
            }
            // Actualizamos el valor2 del nodo que corresponde al telefono
            aux.setValor2(nuevoV2);
        }
    }
        // Método que muestra el menú de opciones que se pueden realizar en este programa
      public void menu(){
        String nombre;
        String telefono;
        String nuevo;
       Scanner s = new Scanner(System.in);
       //Se declara un objeto de la clase Alumno
       Contacto agenda = new Contacto();
       int opcion; //Guardaremos la opcion del usuario
       boolean salir = false;
          while (!salir) {
            System.out.println("\n==================================");
            System.out.println("          MENÚ");
            System.out.println("==================================");
            System.out.println("1. Añadir contacto");
            System.out.println("2. Listar contactos");
            System.out.println("3. Buscar contacto por nombre");
            System.out.println("4. Buscar contacto por teléfono");
            System.out.println("5. Eliminar contacto por nombre");
            System.out.println("6. Eliminar contacto por teléfono");
            System.out.println("7. Actualizar contacto por nombre");
            System.out.println("8. Actualizar contacto por teléfono");
            System.out.println("9. Salir");
            System.out.println("==================================\n");
            try {
                System.out.println("Escribe una de las opciones");
                opcion = s.nextInt();

                switch (opcion) {
                    case 1:
                        //Pido valores
                        System.out.println("Escribe un nombre");
                        nombre = s.next();
                        System.out.println("Escribe un telefono");
                        telefono = s.next();
                        agenda.agregarAlFinal(nombre, telefono);
                        break;
                    case 2:
                         if (agenda.getTamanio()==0) {
                             System.out.println("\n#####################");
                             System.out.println("NO HAY CONTACTOS");
                             System.out.println("#####################");
                        }else{
                            agenda.listar();
                        }
                        break;
                    case 3:
                        //pido el nombre
                        System.out.println("Escribe un nombre");
                        nombre = s.next();
                        System.out.println("\n"+agenda.buscarPorNombre(nombre));
                        
                        break;
                    case 4: 
                        System.out.println("Escribe un número");
                        telefono= s.next();
                        System.out.println("\n"+agenda.buscarPorTelefono(telefono));
                        
                        break;
                        
                    case 5:

                        //pido el nombre
                        System.out.println("Escribe un nombre");
                        nombre = s.next();
                        agenda.eliminarPorNombre(nombre);
                        break;

                    case 6:
                        System.out.println("Escribe un telefono");
                        telefono = s.next();
                        agenda.eliminarPorTelefono(telefono);
                        break;
                    case 7:
                        System.out.println("Dame el nombre del contacto");
                        nombre= s.next();
                        System.out.println("Dame el nuevo nombre del contacto");
                        nuevo= s.next();
                        agenda.editarPorNombre(nombre, nuevo);
                        break;
                     case 8:
                         System.out.println("Dame el telefono del contacto");
                        telefono= s.next();
                        System.out.println("Dame el nuevo telefono del contacto");
                        nuevo= s.next();
                        agenda.editarPorTelefono(telefono, nuevo);
                        break;   
                     //opcion para salir del programa
                    case 9:
                        salir = true;
                        break;
                    default:
                        System.out.println("Solo números entre 1 y 8");
                }
            } catch (InputMismatchException e) {
                System.out.println("Debes insertar un número");
                s.next();
            }
        }
      }
}
